Action()
{

	web_reg_find("Text=New Test", 
		LAST);

	web_url("test.youplace.net", 
		"URL=http://test.youplace.net/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_find("Text=Question 1", 
		LAST);

	web_link("Start test", 
		"Text=Start test", 
		"Snapshot=t14.inf", 
		LAST);

	return 0;
}